﻿namespace FishingZone.Worlds {
	internal class WorldRegion {
		public string Name { get; set; }

		public WorldRegion(string name) {
			Name = name;
		}
	}
}
